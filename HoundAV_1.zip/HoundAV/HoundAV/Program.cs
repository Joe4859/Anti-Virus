﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HoundAV
{
    class Program
    {
        static void Main(string[] args)
        {
            new FileProcessor();
            new MyProcess();
        }

    }
}
